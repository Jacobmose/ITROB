:class:`planar.LineSegment` -- Line Segments
============================================

.. index:: LineSegment, line segment class

.. autoclass:: planar.LineSegment
	:members:
	:inherited-members:

