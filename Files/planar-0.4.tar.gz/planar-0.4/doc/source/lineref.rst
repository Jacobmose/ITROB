:class:`planar.Line` -- Infinite Lines
======================================

.. index:: Line, line class

.. autoclass:: planar.Line
	:members:
	:inherited-members:

