#!/usr/bin/env python

import sys
reload(sys)
sys.setdefaultencoding("utf-8")

import rospy
import actionlib
from CalculateObjectPosition import calcObjectPos
from Recognition import Recognition
from QRfuncs import QRfuncs
from control_msgs.msg import FollowJointTrajectoryAction
from control_msgs.msg import FollowJointTrajectoryFeedback
from control_msgs.msg import FollowJointTrajectoryResult
from control_msgs.msg import FollowJointTrajectoryGoal
from trajectory_msgs.msg import JointTrajectoryPoint
from trajectory_msgs.msg import JointTrajectory
import math
import codecs
import os



def invkin(xyz):
	print("test", xyz)
	"""
	Python implementation of the the inverse kinematics for the crustcrawler
	Input: xyz position
	Output: Angels for each joint: q1,q2,q3,q4
	
	You might adjust parameters (d1,a1,a2,d4).
	The robot model shown in rviz can be adjusted accordingly by editing au_crustcrawler_ax12.urdf
	"""

	d1 = 16.5; # cm (height of 2nd joint)
	a1 = 0.0; # (distance along "y-axis" to 2nd joint)
	a2 = 17.5; # (distance between 2nd and 3rd joints)
	d4 = 24.5; # (distance from 3rd joint to gripper center - all inclusive, ie. also 4th joint)
	
	max = 57.8
	xc = xyz[0];
	yc = xyz[1];
	zc = xyz[2];
	gripper = xyz[3];
	Rotater = xyz[4];
	
	q1 = math.atan2(yc,xc);
	
	r2 = pow((xc - a1*math.cos(q1)),2) + pow((yc - a1*math.sin(q1)),2);
	s = (zc - d1);
	D = (r2 + pow(s,2) - pow(a2,2) - pow(d4,2))/(2*a2*d4);

	q3 = math.atan2(-math.sqrt(1-pow(D,2)), D);
	q2 = math.atan2(s, math.sqrt(r2)) - math.atan2(d4*math.sin(q3), a2 + d4*math.cos(q3));	

	return q1,-(math.pi/2-q2),q3,Rotater, gripper

class QRRobotNode:
	N_JOINTS = 5
	def __init__(self,server_name, x_coord, y_coord, angle, isPickup):
		self.client = actionlib.SimpleActionClient(server_name, FollowJointTrajectoryAction)

		self.joint_positions = []
		self.names =["joint1",
				"joint2",
				"joint3",
				"joint4",
				"gripper"]
		
		# the list of xyz points we want to plan
		#These values are given in centimeters:  
		if isPickup:
			xyz_positions = pickup(x_coord, y_coord)
		else:
			xyz_positions = delivery(x_coord, y_coord, angle)	
		
		# initial duration
		dur = rospy.Duration(2) #Init Speed

		# construct a list of joint positions by calling invkin for each xyz point
		for p in xyz_positions:
			jtp = JointTrajectoryPoint(positions=invkin(p),velocities=[0.5]*self.N_JOINTS ,time_from_start=dur)
			dur += rospy.Duration(1.8) #speed
			self.joint_positions.append(jtp)

		self.jt = JointTrajectory(joint_names=self.names, points=self.joint_positions)
		self.goal = FollowJointTrajectoryGoal( trajectory=self.jt, goal_time_tolerance=dur+rospy.Duration(2) )

	def send_command(self):
		self.client.wait_for_server()
		#print self.goal
		self.client.send_goal(self.goal)

		self.client.wait_for_result()
		#print self.client.get_result()

class ObjectPosition(object):
	def __init__(self, x_coord=None, y_coord=None, color=None, angle=None):
		self.y_coord = y_coord
		self.x_coord = x_coord
		self.color = color
		self.angle = angle
        
def getPattern(QRString):
    print(QRString == "patterntest")
    if QRString == "patterntest":       
        patternTestList = []
        patternTestList.append(ObjectPosition(0, -23, "red", 0))
        patternTestList.append(ObjectPosition(15, -24, "blue", 42))
        patternTestList.append(ObjectPosition(10, -23.3, "green", 32))    
        patternTestList.append(ObjectPosition(5, -23, "yellow", 18))    
        return patternTestList
    elif QRString == "patternbox":
        patternTestList = []
        patternTestList.append(ObjectPosition(12, -24.3, "red", -65))
        patternTestList.append(ObjectPosition(13, -19, "yellow", 42))
        patternTestList.append(ObjectPosition(5, -22, "green", 20))
        patternTestList.append(ObjectPosition(8, -15, "blue", -60))
	return patternTestList
    elif QRString == "patternrectangle":
	patternTestList = []
	patternTestList.append(ObjectPosition(-4.5, -16.7, "yellow", -10.2))
	patternTestList.append(ObjectPosition(-4.5, -24.5, "yellow", -8.59))
	patternTestList.append(ObjectPosition(14.5, -17.7, "red", 42.7))
	patternTestList.append(ObjectPosition(14.5, -25.5, "red", 36.2))
	patternTestList.append(ObjectPosition(1.8, -13, "green", -80.23))
	patternTestList.append(ObjectPosition(2.3, -25.2, "blue", -85))
	patternTestList.append(ObjectPosition(10, -15, "green", -52))
	patternTestList.append(ObjectPosition(9, -25.2, "blue", -72))
	            
        return patternTestList

def pickup(x, y):
	return [[x, y, 10, 0.2, 0],[x, y, 1, 0, 0],[x, y, 0.7, 0.8, 0],[x, y, 10, 0.8, 0],[25, 0, 15, 0.8, 0]]

def delivery(x, y, angle):
	motorAngleValue = angle/58.33
	return [[x, y, 10, 0.8, 0],[x, y, 10, 0.8, motorAngleValue],[x, y, 1, 0.8, motorAngleValue],[x, y, 1, 0.5, motorAngleValue],[x, y, 10, 0.5, motorAngleValue],[25, 0, 15, 0.2, 0]]
	
rospy.init_node("main")
recog = Recognition()
qr_funcs = QRfuncs()

while 1:    
    while not qr_funcs.checkforQRcode():
        print("waiting for QR code")	            
    
    raw_input("QR code found press the enter key to start creating the pattern :-)")
        
    QRString = qr_funcs.getQRString()
    BOM = codecs.BOM_UTF8.decode('utf8')
    patternstring = QRString.lstrip(BOM)
    
    patternArray = getPattern(patternstring)
    
    if not patternArray == None:        
        for position in patternArray:
            print("pickup " + position.color + " brick")
             
            imageurl,image = recog.fetch_image_from_webcam()
            
            pixel_coord = recog.detect_brick(image, position.color)
	    
	    print("Pixel coord ", pixel_coord)
	    if not pixel_coord:
		raw_input("Couldn't detect the " + position.color + "brick, please place a " + position.color + " and press enter")
		imageurl,image = recog.fetch_image_from_webcam()
		pixel_coord = recog.detect_brick(image, position.color)
	    if not pixel_coord:
		raw_input("Second attempt failed quitting current pattern")
		break
            pickup_coord = calcObjectPos.calculateObjectPosition(pixel_coord[0], pixel_coord[1])
            print("Robot coord ", pickup_coord[0],pickup_coord[1])
            node = QRRobotNode("/arm_controller/follow_joint_trajectory", pickup_coord[0], pickup_coord[1], 0, 1)
            node.send_command()
            
            node = QRRobotNode("/arm_controller/follow_joint_trajectory", position.x_coord, position.y_coord, position.angle, 0)
            node.send_command()
            
            print(position.x_coord, position.y_coord)
    else:
        raw_input("No pattern matches the QR code press enter to try again")
