#!/usr/bin/env python

from qrtools import QR
from Recognition import Recognition

class QRfuncs:
        
        def __init__(self):
            self.qrstring = ""
            self.recog = Recognition()
        
        def create_qr_image(self, brickcolor, debug = False):
            qr_creator = QR(data=u"pattern" + brickcolor + "", pixel_size=10)
            qr_creator.encode("pattern" + brickcolor + ".png")
            if debug: print(qr_creator.filename)
            
            return qr_creator.filename
            
        def decode_qr_code(self, filename):
            qr_reader = QR()
            decoded = qr_reader.decode(filename)
            if decoded:
                return decoded,qr_reader.data_to_string()
            else:
                return decoded, None
        
        def checkforQRcode(self, debug = False):
            isdecoded = False
            while not isdecoded:
                imageurl,image = self.recog.fetch_image_from_webcam()
                isdecoded,data = self.decode_qr_code(imageurl)
                                 
                if debug: print(isdecoded)
                if isdecoded:
                    if debug: print(data)                    
                    self.qrstring = data
                    return True
                else:
                    return False
        def getQRString(self):                  
            return self.qrstring      
