#!/usr/bin/env python

from CalculateObjectPosition import calcObjectPos

agh = calcObjectPos.calculateObjectPosition(40,1)

print(agh[0])
