:class:`planar.Vec2` -- 2D Vectors
==================================

.. index:: Vec2, vector class

.. autoclass:: planar.Vec2
	:members:

.. index:: Point

.. class:: planar.Point

	An alias for :class:`~planar.Vec2`. Useful for
	code clarity.
