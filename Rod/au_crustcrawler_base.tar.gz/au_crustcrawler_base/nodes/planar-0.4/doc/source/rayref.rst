:class:`planar.Ray` -- Infinite Semi-Lines
==========================================

.. index:: Ray, ray class

.. autoclass:: planar.Ray
	:members:
	:inherited-members:

